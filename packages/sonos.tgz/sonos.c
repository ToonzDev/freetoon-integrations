/*
 * sonos.c — Native Sonos UPnP / SOAP controller with SSDP auto-discovery.
 * Direct communication with Sonos speakers over local LAN on port 1400.
 * Eliminates external dependencies (no Raspberry Pi or node-sonos-http-api needed).
 */
#include "sonos.h"
#include "settings.h"
#include "display.h"
#include "i18n.h"
#include "screens.h"
#define LV_USE_SJPG 1
#include "lvgl/src/extra/libs/sjpg/tjpgd.h"
#include "lvgl/src/extra/libs/png/lodepng.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <time.h>
#include <fcntl.h>
#include <errno.h>

sonos_state_t sonos_state = {0};

static pthread_mutex_t g_sonos_mtx = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t s_poll_mtx  = PTHREAD_MUTEX_INITIALIZER;
static pthread_t       g_sonos_tid = 0;
static volatile int    g_force_poll = 0;

/* Room topology and IP cache */
typedef struct {
    char room[48];
    char ip[32];
    char uuid[48];
} sonos_room_entry_t;

static sonos_room_entry_t g_rooms[SONOS_MAX_ZONES];
static int                g_room_count = 0;
static char               g_active_ip[64] = "";
static char               g_bootstrap_ip[64] = "";
static int                g_poll_fail_count = 0;

/* Cached favorites for instant playback lookup */
typedef struct {
    char title[64];
    char uri[256];
    char meta[512];
} sonos_fav_entry_t;

static sonos_fav_entry_t g_favs[SONOS_MAX_ITEMS];
static int               g_fav_count = 0;

/* Artwork state and in-memory buffers */
static char            g_cur_art_url[256] = "";
static volatile int    g_art_version = 0;
static volatile int    g_art_downloading = 0;

#define ART_BIG_DIM   SUNI(130)
#define ART_TILE_DIM  SUNI(46)

static lv_color_t g_art_big_buf[ART_BIG_DIM * ART_BIG_DIM];
static lv_color_t g_art_tile_buf[ART_TILE_DIM * ART_TILE_DIM];
static int        g_art_has_image = 0;

static const lv_img_dsc_t g_art_big_dsc = {
    .header.always_zero = 0,
    .header.w = ART_BIG_DIM,
    .header.h = ART_BIG_DIM,
    .data_size = sizeof(g_art_big_buf),
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .data = (const uint8_t *)g_art_big_buf,
};

static const lv_img_dsc_t g_art_tile_dsc = {
    .header.always_zero = 0,
    .header.w = ART_TILE_DIM,
    .header.h = ART_TILE_DIM,
    .data_size = sizeof(g_art_tile_buf),
    .header.cf = LV_IMG_CF_TRUE_COLOR,
    .data = (const uint8_t *)g_art_tile_buf,
};

void sonos_get_snapshot(sonos_state_t * out) {
    if (!out) return;
    pthread_mutex_lock(&g_sonos_mtx);
    *out = sonos_state;
    pthread_mutex_unlock(&g_sonos_mtx);
}

const lv_img_dsc_t * sonos_get_art_big(int * out_ver) {
    pthread_mutex_lock(&g_sonos_mtx);
    if (out_ver) *out_ver = g_art_version;
    const lv_img_dsc_t * ret = g_art_has_image ? &g_art_big_dsc : NULL;
    pthread_mutex_unlock(&g_sonos_mtx);
    return ret;
}

const lv_img_dsc_t * sonos_get_art_tile(int * out_ver) {
    pthread_mutex_lock(&g_sonos_mtx);
    if (out_ver) *out_ver = g_art_version;
    const lv_img_dsc_t * ret = g_art_has_image ? &g_art_tile_dsc : NULL;
    pthread_mutex_unlock(&g_sonos_mtx);
    return ret;
}

/* =========================================================================
 * XML and Time Helpers
 * ========================================================================= */

static int parse_time_seconds(const char * str) {
    if (!str || !str[0]) return 0;
    int h = 0, m = 0, s = 0;
    if (sscanf(str, "%d:%d:%d", &h, &m, &s) == 3) {
        return h * 3600 + m * 60 + s;
    }
    if (sscanf(str, "%d:%d", &m, &s) == 2) {
        return m * 60 + s;
    }
    return atoi(str);
}

static void xml_unescape_in_place(char * s) {
    if (!s || !*s) return;
    for (int pass = 0; pass < 4; pass++) {
        char * r = s;
        char * w = s;
        int changed = 0;
        while (*r) {
            if (*r == '&') {
                if (strncmp(r, "&amp;", 5) == 0) {
                    *w++ = '&'; r += 5; changed = 1;
                } else if (strncmp(r, "&apos;", 6) == 0) {
                    *w++ = '\''; r += 6; changed = 1;
                } else if (strncmp(r, "&apo;", 5) == 0) {
                    *w++ = '\''; r += 5; changed = 1;
                } else if (strncmp(r, "&#39;", 5) == 0) {
                    *w++ = '\''; r += 5; changed = 1;
                } else if (strncmp(r, "&#039;", 6) == 0) {
                    *w++ = '\''; r += 6; changed = 1;
                } else if (strncmp(r, "&#x27;", 6) == 0 || strncmp(r, "&#X27;", 6) == 0) {
                    *w++ = '\''; r += 6; changed = 1;
                } else if (strncmp(r, "&quot;", 6) == 0) {
                    *w++ = '"'; r += 6; changed = 1;
                } else if (strncmp(r, "&#34;", 5) == 0) {
                    *w++ = '"'; r += 5; changed = 1;
                } else if (strncmp(r, "&lt;", 4) == 0) {
                    *w++ = '<'; r += 4; changed = 1;
                } else if (strncmp(r, "&gt;", 4) == 0) {
                    *w++ = '>'; r += 4; changed = 1;
                } else if (strncmp(r, "&nbsp;", 6) == 0) {
                    *w++ = ' '; r += 6; changed = 1;
                } else if (strncmp(r, "&#8216;", 7) == 0 || strncmp(r, "&#8217;", 7) == 0 ||
                           strncmp(r, "&rsquo;", 7) == 0 || strncmp(r, "&lsquo;", 7) == 0) {
                    *w++ = '\''; r += 7; changed = 1;
                } else if (strncmp(r, "&#8220;", 7) == 0 || strncmp(r, "&#8221;", 7) == 0 ||
                           strncmp(r, "&rdquo;", 7) == 0 || strncmp(r, "&ldquo;", 7) == 0) {
                    *w++ = '"'; r += 7; changed = 1;
                } else if (strncmp(r, "&#8211;", 7) == 0 || strncmp(r, "&#8212;", 7) == 0 ||
                           strncmp(r, "&ndash;", 7) == 0 || strncmp(r, "&mdash;", 7) == 0) {
                    *w++ = '-'; r += 7; changed = 1;
                } else {
                    *w++ = *r++;
                }
            } else {
                *w++ = *r++;
            }
        }
        *w = '\0';
        if (!changed) break;
    }
}

void sonos_sanitize_utf8(char * str) {
    if (!str || !*str) return;
    unsigned char * r = (unsigned char *)str;
    char * w = str;

    while (*r) {
        /* Skip 4-byte UTF-8 sequences (emojis, etc. U+10000..U+1FFFFF) */
        if ((r[0] & 0xF8) == 0xF0) {
            r += 4;
            continue;
        }
        /* Check 3-byte UTF-8 punctuation */
        if (r[0] == 0xE2 && r[1] == 0x80) {
            unsigned char b3 = r[2];
            if (b3 >= 0x98 && b3 <= 0x9B) { /* ‘ ’ ‚ ‛ */
                *w++ = '\'';
                r += 3;
                continue;
            } else if (b3 >= 0x9C && b3 <= 0x9F) { /* “ ” „ ‟ */
                *w++ = '"';
                r += 3;
                continue;
            } else if (b3 >= 0x90 && b3 <= 0x95) { /* ‐ ‑ ‒ – — ― */
                *w++ = '-';
                r += 3;
                continue;
            } else if (b3 == 0xA6) { /* … (ellipsis) */
                *w++ = '.';
                r += 3;
                continue;
            } else if (b3 == 0xA2) { /* • (bullet) */
                *w++ = '-';
                r += 3;
                continue;
            } else if (b3 == 0x8B) { /* Zero-width space */
                r += 3;
                continue;
            }
        }
        /* Check 3-byte UTF-8 primes / apostrophes */
        if (r[0] == 0xE2 && r[1] == 0x80 && (r[2] == 0xB2 || r[2] == 0xB3)) { /* ′ ″ */
            *w++ = (r[2] == 0xB2) ? '\'' : '"';
            r += 3;
            continue;
        }
        /* Check 3-byte UTF-8 variation selector (e.g. U+FE0F) or BOM (U+FEFF) */
        if (r[0] == 0xEF && r[1] == 0xB8 && r[2] == 0x8F) {
            r += 3;
            continue;
        }
        if (r[0] == 0xEF && r[1] == 0xBB && r[2] == 0xBF) {
            r += 3;
            continue;
        }
        /* Check 2-byte UTF-8 sequences starting with 0xC2 */
        if (r[0] == 0xC2) {
            if (r[1] == 0xA0) { /* Non-breaking space */
                *w++ = ' ';
                r += 2;
                continue;
            } else if (r[1] == 0xAD) { /* Soft hyphen */
                r += 2;
                continue;
            } else if (r[1] == 0xB4) { /* Acute accent ´ */
                *w++ = '\'';
                r += 2;
                continue;
            } else if (r[1] == 0xAB || r[1] == 0xBB) { /* « » */
                *w++ = '"';
                r += 2;
                continue;
            }
        }
        *w++ = (char)*r++;
    }
    *w = '\0';
}

static void clean_url(char * url) {
    if (!url) return;
    char * p;
    while ((p = strstr(url, "&amp;")) != NULL) {
        memmove(p + 1, p + 5, strlen(p + 5) + 1);
    }
}

/* Extracts contents of <tag>...</tag> or &lt;tag...&gt;...&lt;/tag&gt; */
static int extract_xml_tag(const char * xml, const char * tag, char * out, size_t outsz) {
    if (!xml || !tag || !out || outsz == 0) return 0;
    out[0] = 0;

    char open1[64], open2[64];
    snprintf(open1, sizeof open1, "<%s", tag);
    snprintf(open2, sizeof open2, "&lt;%s", tag);
    size_t tlen = strlen(tag);

    const char * cur = xml;
    const char * p = NULL;
    int is_esc = 0;

    while (*cur) {
        const char * p1 = strstr(cur, open1);
        const char * p2 = strstr(cur, open2);
        if (!p1 && !p2) return 0;

        if (p1 && (!p2 || p1 < p2)) {
            char next = p1[1 + tlen];
            if (next == '>' || next == ' ' || next == '/' || next == '\t' || next == '\r' || next == '\n') {
                p = p1;
                is_esc = 0;
                break;
            }
            cur = p1 + 1;
        } else {
            const char * after = p2 + 4 + tlen;
            if (*after == ' ' || *after == '/' || *after == '\t' || *after == '\r' || *after == '\n' ||
                strncmp(after, "&gt;", 4) == 0) {
                p = p2;
                is_esc = 1;
                break;
            }
            cur = p2 + 1;
        }
    }
    if (!p) return 0;

    if (is_esc) {
        p = strstr(p, "&gt;");
        if (!p) return 0;
        p += 4;
    } else {
        p = strchr(p, '>');
        if (!p) return 0;
        p++;
    }

    char close1[64], close2[64];
    snprintf(close1, sizeof close1, "</%s>", tag);
    snprintf(close2, sizeof close2, "&lt;/%s&gt;", tag);

    const char * end = is_esc ? strstr(p, close2) : strstr(p, close1);
    if (!end) end = is_esc ? strstr(p, close1) : strstr(p, close2);
    if (!end) return 0;

    size_t o = 0;
    while (p < end && o + 1 < outsz) {
        out[o++] = *p++;
    }
    out[o] = 0;

    xml_unescape_in_place(out);
    sonos_sanitize_utf8(out);
    return (o > 0);
}

/* Extracts attr="value" or attr=&quot;value&quot; */
static int extract_xml_attr(const char * xml, const char * attr, char * out, size_t outsz) {
    if (!xml || !attr || !out || outsz == 0) return 0;
    out[0] = 0;

    char needle1[64], needle2[64];
    snprintf(needle1, sizeof needle1, "%s=\"", attr);
    snprintf(needle2, sizeof needle2, "%s=&quot;", attr);

    const char * p = strstr(xml, needle1);
    size_t skip = strlen(needle1);
    const char * close_quote = "\"";
    if (!p) {
        p = strstr(xml, needle2);
        skip = strlen(needle2);
        close_quote = "&quot;";
    }
    if (!p) return 0;
    p += skip;

    const char * end = strstr(p, close_quote);
    if (!end) return 0;

    size_t len = (size_t)(end - p);
    if (len >= outsz) len = outsz - 1;
    memcpy(out, p, len);
    out[len] = 0;
    xml_unescape_in_place(out);
    sonos_sanitize_utf8(out);
    return 1;
}

static void xml_escape(const char * src, char * dst, size_t dst_sz) {
    if (!src || !dst || dst_sz == 0) return;
    size_t o = 0;
    for (const char * p = src; *p && o + 6 < dst_sz; p++) {
        switch (*p) {
            case '&': memcpy(dst + o, "&amp;", 5); o += 5; break;
            case '<': memcpy(dst + o, "&lt;", 4);  o += 4; break;
            case '>': memcpy(dst + o, "&gt;", 4);  o += 4; break;
            case '"': memcpy(dst + o, "&quot;", 6); o += 6; break;
            default:  dst[o++] = *p; break;
        }
    }
    dst[o] = 0;
}

/* =========================================================================
 * Native UPnP SOAP Client
 * ========================================================================= */

static int sonos_soap(const char * ip, const char * control_path,
                      const char * service, const char * action,
                      const char * body_args,
                      char * out_buf, size_t out_sz, int timeout_s) {
    if (!ip || !ip[0] || !control_path || !service || !action) return -1;
    if (out_buf && out_sz > 0) out_buf[0] = 0;

    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return -1;

    struct timeval tv;
    tv.tv_sec = timeout_s > 0 ? timeout_s : 3;
    tv.tv_usec = 0;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    struct sockaddr_in sin;
    memset(&sin, 0, sizeof(sin));
    sin.sin_family = AF_INET;
    sin.sin_port = htons(1400);
    sin.sin_addr.s_addr = inet_addr(ip);

    if (connect(fd, (struct sockaddr *)&sin, sizeof(sin)) != 0) {
        close(fd);
        return -1;
    }

    char body[4096];
    int blen = snprintf(body, sizeof(body),
        "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
        "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">"
        "<s:Body>"
        "<u:%s xmlns:u=\"%s\">"
        "%s"
        "</u:%s>"
        "</s:Body>"
        "</s:Envelope>",
        action, service, body_args ? body_args : "", action);

    char header[512];
    int hlen = snprintf(header, sizeof(header),
        "POST %s HTTP/1.1\r\n"
        "Host: %s:1400\r\n"
        "Content-Type: text/xml; charset=\"utf-8\"\r\n"
        "Content-Length: %d\r\n"
        "SOAPACTION: \"%s#%s\"\r\n"
        "Connection: close\r\n"
        "\r\n",
        control_path, ip, blen, service, action);

    if (send(fd, header, hlen, 0) != hlen || send(fd, body, blen, 0) != blen) {
        close(fd);
        return -1;
    }

    char scratch[1024];
    char * target = (out_buf && out_sz > 0) ? out_buf : scratch;
    size_t target_sz = (out_buf && out_sz > 0) ? out_sz : sizeof(scratch);

    size_t total = 0;
    int got_200 = 0;
    while (1) {
        size_t cap = (total + 1 < target_sz) ? (target_sz - 1 - total) : (sizeof(scratch) - 1);
        char * dest = (total + 1 < target_sz) ? (target + total) : scratch;
        ssize_t r = recv(fd, dest, cap, 0);
        if (r <= 0) break;
        if (total + 1 < target_sz) {
            total += r;
            target[total] = 0;
        }
        if (!got_200 && (strstr(target, "200 OK") != NULL)) {
            got_200 = 1;
        }
    }
    close(fd);

    return got_200 ? 0 : -2;
}

/* =========================================================================
 * SSDP Auto-Discovery (M-SEARCH multicast)
 * ========================================================================= */

static int sonos_ssdp_discover(char * out_ip, size_t out_sz, int timeout_ms) {
    if (!out_ip || out_sz < 16) return 0;
    out_ip[0] = 0;

    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) return 0;

    struct timeval tv;
    tv.tv_sec = timeout_ms / 1000;
    tv.tv_usec = (timeout_ms % 1000) * 1000;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    int ttl = 4;
    setsockopt(fd, IPPROTO_IP, IP_MULTICAST_TTL, &ttl, sizeof(ttl));

    struct sockaddr_in dst;
    memset(&dst, 0, sizeof(dst));
    dst.sin_family = AF_INET;
    dst.sin_port = htons(1900);
    dst.sin_addr.s_addr = inet_addr("239.255.255.250");

    const char * msg =
        "M-SEARCH * HTTP/1.1\r\n"
        "HOST: 239.255.255.250:1900\r\n"
        "MAN: \"ssdp:discover\"\r\n"
        "MX: 2\r\n"
        "ST: urn:schemas-upnp-org:device:ZonePlayer:1\r\n"
        "\r\n";

    if (sendto(fd, msg, strlen(msg), 0, (struct sockaddr *)&dst, sizeof(dst)) < 0) {
        close(fd);
        return 0;
    }

    char buf[2048];
    struct sockaddr_in src;
    socklen_t slen = sizeof(src);
    int found = 0;

    while (1) {
        slen = sizeof(src);
        ssize_t n = recvfrom(fd, buf, sizeof(buf) - 1, 0, (struct sockaddr *)&src, &slen);
        if (n <= 0) break;
        buf[n] = 0;

        if (strstr(buf, "ZonePlayer") || strstr(buf, "Sonos") || strstr(buf, ":1400")) {
            char * loc = strstr(buf, "LOCATION:");
            if (!loc) loc = strstr(buf, "location:");
            if (loc) {
                char * hip = strstr(loc, "http://");
                if (hip) {
                    hip += 7;
                    char * colon = strchr(hip, ':');
                    char * slash = strchr(hip, '/');
                    char * end = colon ? colon : slash;
                    if (end && (size_t)(end - hip) < out_sz) {
                        size_t iplen = end - hip;
                        memcpy(out_ip, hip, iplen);
                        out_ip[iplen] = 0;
                        found = 1;
                        break;
                    }
                }
            }
            if (!found && src.sin_addr.s_addr != 0) {
                const char * ip_str = inet_ntoa(src.sin_addr);
                if (ip_str && strlen(ip_str) < out_sz) {
                    snprintf(out_ip, out_sz, "%s", ip_str);
                    found = 1;
                    break;
                }
            }
        }
    }

    close(fd);
    return found;
}

/* =========================================================================
 * Topology Discovery & Room Resolution
 * ========================================================================= */

static int update_topology(const char * bootstrap_ip) {
    if (!bootstrap_ip || !bootstrap_ip[0]) return 0;

    char * resp = malloc(65536);
    if (!resp) return 0;
    resp[0] = 0;

    int rc = sonos_soap(bootstrap_ip, "/ZoneGroupTopology/Control",
                        "urn:schemas-upnp-org:service:ZoneGroupTopology:1",
                        "GetZoneGroupState", "", resp, 65536, 3);
    if (rc != 0 || resp[0] == 0) {
        free(resp);
        return 0;
    }

    g_room_count = 0;

    const char * zg = resp;
    while ((zg = strstr(zg, "Coordinator=")) != NULL && g_room_count < SONOS_MAX_ZONES) {
        char coord_uuid[48] = "";
        extract_xml_attr(zg, "Coordinator", coord_uuid, sizeof coord_uuid);
        char * c = strchr(coord_uuid, ':'); if (c) *c = 0;

        const char * zg_end = strstr(zg, "</ZoneGroup>");
        if (!zg_end) zg_end = strstr(zg, "&lt;/ZoneGroup&gt;");
        if (!zg_end) break;

        const char * mem = zg;
        while ((mem = strstr(mem, "ZoneGroupMember")) != NULL && mem < zg_end) {
            char zname[48] = "";
            char loc[128] = "";
            char uuid[48] = "";

            extract_xml_attr(mem, "ZoneName", zname, sizeof zname);
            extract_xml_attr(mem, "Location", loc, sizeof loc);
            extract_xml_attr(mem, "UUID", uuid, sizeof uuid);
            char * u = strchr(uuid, ':'); if (u) *u = 0;

            if (coord_uuid[0] && strcmp(uuid, coord_uuid) == 0 && zname[0] && loc[0]) {
                char member_ip[32] = "";
                const char * hip = strstr(loc, "http://");
                if (hip) {
                    hip += 7;
                    const char * colon = strchr(hip, ':');
                    if (colon && (size_t)(colon - hip) < sizeof member_ip) {
                        memcpy(member_ip, hip, colon - hip);
                        member_ip[colon - hip] = 0;
                    }
                }
                if (member_ip[0]) {
                    int dup = 0;
                    for (int i = 0; i < g_room_count; i++) {
                        if (strcmp(g_rooms[i].room, zname) == 0) { dup = 1; break; }
                    }
                    if (!dup) {
                        snprintf(g_rooms[g_room_count].room, sizeof g_rooms[0].room, "%s", zname);
                        snprintf(g_rooms[g_room_count].ip, sizeof g_rooms[0].ip, "%s", member_ip);
                        snprintf(g_rooms[g_room_count].uuid, sizeof g_rooms[0].uuid, "%s", uuid);
                        g_room_count++;
                    }
                }
            }
            mem += 15;
        }
        zg = zg_end;
    }
    free(resp);

    /* Update active coordinator IP */
    g_active_ip[0] = 0;
    if (g_room_count > 0) {
        for (int i = 0; i < g_room_count; i++) {
            if (settings.sonos_zone[0] && strcasecmp(settings.sonos_zone, g_rooms[i].room) == 0) {
                snprintf(g_active_ip, sizeof g_active_ip, "%s", g_rooms[i].ip);
                break;
            }
        }
        if (!g_active_ip[0]) {
            /* Default to first room */
            snprintf(g_active_ip, sizeof g_active_ip, "%s", g_rooms[0].ip);
            if (!settings.sonos_zone[0]) {
                snprintf(settings.sonos_zone, sizeof settings.sonos_zone, "%s", g_rooms[0].room);
            }
        }
        if (g_active_ip[0]) {
            snprintf(settings.sonos_host, sizeof settings.sonos_host, "%s", g_active_ip);
            mkdir("/mnt/data/integrations/sonos", 0755);
            FILE * fip = fopen("/mnt/data/integrations/sonos/speaker.ip", "w");
            if (fip) { fprintf(fip, "%s\n", g_active_ip); fclose(fip); }
            if (settings.sonos_zone[0]) {
                FILE * fz = fopen("/mnt/data/integrations/sonos/zone", "w");
                if (fz) { fprintf(fz, "%s\n", settings.sonos_zone); fclose(fz); }
            }
        }
    }
    return g_room_count;
}

/* =========================================================================
 * Fast TCP Port 1400 Subnet Scan (Bypasses local UDP firewall restrictions)
 * ========================================================================= */

static int get_local_subnet_prefix(char * out_prefix, size_t out_sz) {
    if (!out_prefix || out_sz < 16) return -1;
    out_prefix[0] = 0;

    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd >= 0) {
        struct sockaddr_in probe;
        memset(&probe, 0, sizeof(probe));
        probe.sin_family = AF_INET;
        probe.sin_port = htons(53);
        probe.sin_addr.s_addr = inet_addr("1.1.1.1");
        if (connect(fd, (struct sockaddr *)&probe, sizeof(probe)) == 0) {
            struct sockaddr_in local;
            socklen_t len = sizeof(local);
            if (getsockname(fd, (struct sockaddr *)&local, &len) == 0) {
                const char * ip = inet_ntoa(local.sin_addr);
                if (ip && strncmp(ip, "127.", 4) != 0 && strcmp(ip, "0.0.0.0") != 0) {
                    const char * last_dot = strrchr(ip, '.');
                    if (last_dot && (size_t)(last_dot - ip) < out_sz) {
                        size_t n = last_dot - ip;
                        memcpy(out_prefix, ip, n);
                        out_prefix[n] = 0;
                        close(fd);
                        return 0;
                    }
                }
            }
        }
        close(fd);
    }
    snprintf(out_prefix, out_sz, "192.168.2");
    return 0;
}

#define TCP_SCAN_BATCH 64

static int sonos_tcp_discover(char * out_ip, size_t out_sz) {
    if (!out_ip || out_sz < 16) return 0;
    out_ip[0] = 0;

    char prefix[32] = "";
    get_local_subnet_prefix(prefix, sizeof prefix);
    if (!prefix[0]) snprintf(prefix, sizeof prefix, "192.168.2");

    int fds[TCP_SCAN_BATCH];
    char ips[TCP_SCAN_BATCH][32];

    for (int start_host = 1; start_host <= 254; start_host += TCP_SCAN_BATCH) {
        int end_host = start_host + TCP_SCAN_BATCH - 1;
        if (end_host > 254) end_host = 254;
        int count = end_host - start_host + 1;

        int max_fd = -1;
        fd_set wfds;
        FD_ZERO(&wfds);

        for (int i = 0; i < count; i++) {
            fds[i] = -1;
            int host_num = start_host + i;
            snprintf(ips[i], sizeof ips[i], "%s.%d", prefix, host_num);

            int fd = socket(AF_INET, SOCK_STREAM, 0);
            if (fd < 0) continue;

            int flags = fcntl(fd, F_GETFL, 0);
            if (flags >= 0) fcntl(fd, F_SETFL, flags | O_NONBLOCK);

            struct sockaddr_in sin;
            memset(&sin, 0, sizeof(sin));
            sin.sin_family = AF_INET;
            sin.sin_port = htons(1400);
            sin.sin_addr.s_addr = inet_addr(ips[i]);

            connect(fd, (struct sockaddr *)&sin, sizeof(sin));
            fds[i] = fd;
            FD_SET(fd, &wfds);
            if (fd > max_fd) max_fd = fd;
        }

        struct timeval tv;
        tv.tv_sec = 0;
        tv.tv_usec = 300000; /* 300 ms */

        char candidates[8][32];
        int num_cand = 0;

        if (max_fd >= 0) {
            int sel = select(max_fd + 1, NULL, &wfds, NULL, &tv);
            if (sel > 0) {
                for (int i = 0; i < count && num_cand < 8; i++) {
                    if (fds[i] >= 0 && FD_ISSET(fds[i], &wfds)) {
                        int err = 0;
                        socklen_t elen = sizeof(err);
                        if (getsockopt(fds[i], SOL_SOCKET, SO_ERROR, &err, &elen) == 0 && err == 0) {
                            snprintf(candidates[num_cand++], 32, "%s", ips[i]);
                        }
                    }
                }
            }
        }

        /* Close all sockets in this batch */
        for (int i = 0; i < count; i++) {
            if (fds[i] >= 0) close(fds[i]);
        }

        /* For each host that opened port 1400, test Sonos topology */
        for (int c = 0; c < num_cand; c++) {
            if (update_topology(candidates[c]) > 0) {
                snprintf(out_ip, out_sz, "%s", candidates[c]);
                return 1;
            }
        }
    }
    return 0;
}

int sonos_probe(char zones[][48], int max_zones) {
    if (!g_bootstrap_ip[0]) {
        FILE * fip = fopen("/mnt/data/integrations/sonos/speaker.ip", "r");
        if (fip) {
            if (fgets(g_bootstrap_ip, sizeof(g_bootstrap_ip), fip)) {
                char * p = strchr(g_bootstrap_ip, '\n'); if (p) *p = 0;
                p = strchr(g_bootstrap_ip, '\r'); if (p) *p = 0;
            }
            fclose(fip);
        }
    }
    if (g_bootstrap_ip[0]) {
        if (update_topology(g_bootstrap_ip) == 0) {
            g_bootstrap_ip[0] = 0;
        }
    }
    if (!g_bootstrap_ip[0]) {
        /* Primary: Fast TCP subnet probe on port 1400 */
        sonos_tcp_discover(g_bootstrap_ip, sizeof g_bootstrap_ip);

        /* Secondary: SSDP discovery fallback */
        if (!g_bootstrap_ip[0]) {
            sonos_ssdp_discover(g_bootstrap_ip, sizeof g_bootstrap_ip, 1200);
        }
    }
    if (g_bootstrap_ip[0] && g_room_count == 0) {
        update_topology(g_bootstrap_ip);
    }
    int count = (g_room_count < max_zones) ? g_room_count : max_zones;
    for (int i = 0; i < count; i++) {
        snprintf(zones[i], 48, "%s", g_rooms[i].room);
    }
    return count;
}

/* =========================================================================
 * Artwork Decoding & In-Memory Downscaling
 * ========================================================================= */

typedef struct {
    char url[256];
} art_req_t;

typedef struct {
    const uint8_t * data;
    size_t size;
    size_t pos;
    uint8_t * rgb_buf;
    int w, h;
} jdec_session_t;

static size_t jdec_infunc(JDEC * jd, uint8_t * buff, size_t ndata) {
    jdec_session_t * s = (jdec_session_t *)jd->device;
    size_t left = s->size > s->pos ? s->size - s->pos : 0;
    size_t to_read = ndata < left ? ndata : left;
    if (buff && to_read > 0) {
        memcpy(buff, s->data + s->pos, to_read);
    }
    s->pos += to_read;
    return to_read;
}

static int jdec_outfunc(JDEC * jd, void * bitmap, JRECT * rect) {
    jdec_session_t * s = (jdec_session_t *)jd->device;
    uint8_t * src = (uint8_t *)bitmap;
    int rw = rect->right - rect->left + 1;
    for (int y = rect->top; y <= rect->bottom; y++) {
        if (y < s->h) {
            int copy_w = rw;
            if (rect->left + copy_w > s->w) copy_w = s->w - rect->left;
            if (copy_w > 0 && rect->left < s->w) {
                uint8_t * dst = s->rgb_buf + (y * s->w + rect->left) * 3;
                memcpy(dst, src, copy_w * 3);
            }
        }
        src += rw * 3;
    }
    return 1;
}

static void resample_to_lv_color(const uint8_t * src, int src_w, int src_h, int channels,
                                 lv_color_t * dst, int dst_w, int dst_h) {
    if (!src || !dst || src_w <= 0 || src_h <= 0 || dst_w <= 0 || dst_h <= 0) return;
    int src_stride = src_w * channels;

    int crop_x = 0, crop_y = 0, crop_w = src_w, crop_h = src_h;
    if (src_w > src_h) {
        crop_w = src_h;
        crop_x = (src_w - src_h) / 2;
    } else if (src_h > src_w) {
        crop_h = src_w;
        crop_y = (src_h - src_w) / 2;
    }

    for (int dy = 0; dy < dst_h; dy++) {
        int64_t sy16 = ((int64_t)dy * crop_h * 65536) / dst_h;
        int y0 = crop_y + (int)(sy16 >> 16);
        if (y0 < 0) y0 = 0;
        if (y0 >= src_h) y0 = src_h - 1;
        int y1 = (y0 + 1 < crop_y + crop_h && y0 + 1 < src_h) ? y0 + 1 : y0;
        int y_frac = (sy16 >> 8) & 0xff;

        for (int dx = 0; dx < dst_w; dx++) {
            int64_t sx16 = ((int64_t)dx * crop_w * 65536) / dst_w;
            int x0 = crop_x + (int)(sx16 >> 16);
            if (x0 < 0) x0 = 0;
            if (x0 >= src_w) x0 = src_w - 1;
            int x1 = (x0 + 1 < crop_x + crop_w && x0 + 1 < src_w) ? x0 + 1 : x0;
            int x_frac = (sx16 >> 8) & 0xff;

            int w00 = (256 - x_frac) * (256 - y_frac);
            int w10 = x_frac * (256 - y_frac);
            int w01 = (256 - x_frac) * y_frac;
            int w11 = x_frac * y_frac;

            const uint8_t * p00 = src + y0 * src_stride + x0 * channels;
            const uint8_t * p10 = src + y0 * src_stride + x1 * channels;
            const uint8_t * p01 = src + y1 * src_stride + x0 * channels;
            const uint8_t * p11 = src + y1 * src_stride + x1 * channels;

            uint8_t r = (p00[0] * w00 + p10[0] * w10 + p01[0] * w01 + p11[0] * w11 + 32768) >> 16;
            uint8_t g = (p00[1] * w00 + p10[1] * w10 + p01[1] * w01 + p11[1] * w11 + 32768) >> 16;
            uint8_t b = (p00[2] * w00 + p10[2] * w10 + p01[2] * w01 + p11[2] * w11 + 32768) >> 16;

            dst[dy * dst_w + dx] = lv_color_make(r, g, b);
        }
    }
}

static void * art_download_worker(void * arg) {
    art_req_t * req = (art_req_t *)arg;
    char tmp[64] = "/tmp/sonos_art_dl.tmp";
    clean_url(req->url);

    char safe_url[512];
    size_t si = 0;
    for (size_t i = 0; req->url[i] && si + 4 < sizeof safe_url; i++) {
        if (req->url[i] == '\'') {
            safe_url[si++] = '%'; safe_url[si++] = '2'; safe_url[si++] = '7';
        } else {
            safe_url[si++] = req->url[i];
        }
    }
    safe_url[si] = 0;

    unlink(tmp);
    char cmd[640];
    snprintf(cmd, sizeof cmd, "curl -s -L --connect-timeout 3 --max-time 6 -o %s '%s' 2>/dev/null", tmp, safe_url);
    int rc = system(cmd);
    bool ok = false;
    lv_color_t * tmp_big = malloc(sizeof(g_art_big_buf));
    lv_color_t * tmp_tile = malloc(sizeof(g_art_tile_buf));

    if (rc == 0 && tmp_big && tmp_tile) {
        FILE * f = fopen(tmp, "rb");
        if (f) {
            fseek(f, 0, SEEK_END);
            long fsz = ftell(f);
            fseek(f, 0, SEEK_SET);
            if (fsz > 4 && fsz < 5 * 1024 * 1024) {
                uint8_t * fbuf = malloc(fsz);
                if (fbuf) {
                    if (fread(fbuf, 1, fsz, f) == (size_t)fsz) {
                        if (fbuf[0] == 0xFF && fbuf[1] == 0xD8) {
                            /* JPEG */
                            void * work = malloc(32768);
                            if (work) {
                                jdec_session_t s = { .data = fbuf, .size = (size_t)fsz, .pos = 0, .rgb_buf = NULL, .w = 0, .h = 0 };
                                JDEC jd;
                                if (jd_prepare(&jd, jdec_infunc, work, 32768, &s) == JDR_OK) {
                                    s.w = jd.width;
                                    s.h = jd.height;
                                    s.rgb_buf = malloc(s.w * s.h * 3);
                                    if (s.rgb_buf) {
                                        if (jd_decomp(&jd, jdec_outfunc, 0) == JDR_OK) {
                                            resample_to_lv_color(s.rgb_buf, s.w, s.h, 3, tmp_big, ART_BIG_DIM, ART_BIG_DIM);
                                            resample_to_lv_color(s.rgb_buf, s.w, s.h, 3, tmp_tile, ART_TILE_DIM, ART_TILE_DIM);
                                            ok = true;
                                        }
                                        free(s.rgb_buf);
                                    }
                                }
                                free(work);
                            }
                        } else if (fbuf[0] == 0x89 && fbuf[1] == 'P' && fbuf[2] == 'N' && fbuf[3] == 'G') {
                            /* PNG */
                            uint8_t * img = NULL;
                            unsigned pw = 0, ph = 0;
                            if (lodepng_decode24(&img, &pw, &ph, fbuf, fsz) == 0 && img) {
                                resample_to_lv_color(img, (int)pw, (int)ph, 3, tmp_big, ART_BIG_DIM, ART_BIG_DIM);
                                resample_to_lv_color(img, (int)pw, (int)ph, 3, tmp_tile, ART_TILE_DIM, ART_TILE_DIM);
                                free(img);
                                ok = true;
                            }
                        }
                    }
                    free(fbuf);
                }
            }
            fclose(f);
        }
        unlink(tmp);
    }

    pthread_mutex_lock(&g_sonos_mtx);
    if (ok) {
        memcpy(g_art_big_buf, tmp_big, sizeof(g_art_big_buf));
        memcpy(g_art_tile_buf, tmp_tile, sizeof(g_art_tile_buf));
        g_art_has_image = 1;
        g_art_version++;
    } else {
        g_art_has_image = 0;
        g_art_version++;
    }
    g_art_downloading = 0;
    pthread_mutex_unlock(&g_sonos_mtx);

    free(tmp_big);
    free(tmp_tile);
    free(req);
    return NULL;
}

static void check_trigger_art_download(const char * new_url) {
    if (!new_url || !new_url[0]) {
        pthread_mutex_lock(&g_sonos_mtx);
        if (g_art_has_image) {
            g_art_has_image = 0;
            g_cur_art_url[0] = 0;
            g_art_version++;
        }
        pthread_mutex_unlock(&g_sonos_mtx);
        return;
    }

    pthread_mutex_lock(&g_sonos_mtx);
    if (strcmp(g_cur_art_url, new_url) == 0 || g_art_downloading) {
        pthread_mutex_unlock(&g_sonos_mtx);
        return;
    }
    snprintf(g_cur_art_url, sizeof g_cur_art_url, "%s", new_url);
    g_art_downloading = 1;
    pthread_mutex_unlock(&g_sonos_mtx);

    art_req_t * req = malloc(sizeof *req);
    if (!req) {
        pthread_mutex_lock(&g_sonos_mtx);
        g_art_downloading = 0;
        pthread_mutex_unlock(&g_sonos_mtx);
        return;
    }
    snprintf(req->url, sizeof req->url, "%s", new_url);

    pthread_t tid;
    if (pthread_create(&tid, NULL, art_download_worker, req) == 0) {
        pthread_detach(tid);
    } else {
        free(req);
        pthread_mutex_lock(&g_sonos_mtx);
        g_art_downloading = 0;
        pthread_mutex_unlock(&g_sonos_mtx);
    }
}

/* =========================================================================
 * Background State Polling
 * ========================================================================= */

static void poll_state(void) {
    pthread_mutex_lock(&s_poll_mtx);

    /* Fast-path IP recovery before expensive network scans */
    if (!g_active_ip[0]) {
        if (!g_bootstrap_ip[0]) {
            FILE * fip = fopen("/mnt/data/integrations/sonos/speaker.ip", "r");
            if (fip) {
                if (fgets(g_bootstrap_ip, sizeof(g_bootstrap_ip), fip)) {
                    char * p = strchr(g_bootstrap_ip, '\n'); if (p) *p = 0;
                    p = strchr(g_bootstrap_ip, '\r'); if (p) *p = 0;
                }
                fclose(fip);
            }
        }
        if (settings.sonos_host[0]) {
            if (update_topology(settings.sonos_host) > 0 && g_active_ip[0]) {
                /* Successfully resolved from saved host */
            }
        }
        if (!g_active_ip[0]) {
            for (int i = 0; i < g_room_count; i++) {
                if (g_rooms[i].ip[0] && update_topology(g_rooms[i].ip) > 0 && g_active_ip[0]) {
                    break;
                }
            }
        }
        if (!g_active_ip[0] && g_bootstrap_ip[0]) {
            if (update_topology(g_bootstrap_ip) > 0 && g_active_ip[0]) {
                /* Resolved from bootstrap */
            }
        }
        /* Fall back to subnet scan ONLY if all known cached IPs fail */
        if (!g_active_ip[0]) {
            sonos_tcp_discover(g_bootstrap_ip, sizeof g_bootstrap_ip);
            if (!g_bootstrap_ip[0]) {
                sonos_ssdp_discover(g_bootstrap_ip, sizeof g_bootstrap_ip, 1200);
            }
            if (g_bootstrap_ip[0]) {
                update_topology(g_bootstrap_ip);
            }
        }
        if (!g_active_ip[0]) {
            pthread_mutex_lock(&g_sonos_mtx);
            sonos_state.connected = 0;
            pthread_mutex_unlock(&g_sonos_mtx);
            pthread_mutex_unlock(&s_poll_mtx);
            return;
        }
    }

    char * buf = malloc(32768);
    if (!buf) {
        pthread_mutex_unlock(&s_poll_mtx);
        return;
    }

    /* Start with a copy of current state to avoid wiping metadata on a single packet drop */
    pthread_mutex_lock(&g_sonos_mtx);
    sonos_state_t st = sonos_state;
    pthread_mutex_unlock(&g_sonos_mtx);

    snprintf(st.zone, sizeof st.zone, "%s", settings.sonos_zone[0] ? settings.sonos_zone : "Sonos");

    /* 1. GetTransportInfo */
    buf[0] = 0;
    int rc = sonos_soap(g_active_ip, "/MediaRenderer/AVTransport/Control",
                        "urn:schemas-upnp-org:service:AVTransport:1",
                        "GetTransportInfo", "<InstanceID>0</InstanceID>", buf, 32768, 2);
    if (rc == 0) {
        g_poll_fail_count = 0;
        st.connected = 1;
        char state[32] = "";
        extract_xml_tag(buf, "CurrentTransportState", state, sizeof state);
        st.playing = (strcmp(state, "PLAYING") == 0 || strcmp(state, "TRANSITIONING") == 0);
    } else {
        /* Transient glitch: do not instantly disconnect or clear IP */
        g_poll_fail_count++;
        if (g_poll_fail_count >= 8) {
            pthread_mutex_lock(&g_sonos_mtx);
            sonos_state.connected = 0;
            pthread_mutex_unlock(&g_sonos_mtx);
        }
        /* Only forget IPs after persistent prolonged failure (30 failed polls) */
        if (g_poll_fail_count >= 30) {
            g_active_ip[0] = 0;
            g_bootstrap_ip[0] = 0;
        }
        free(buf);
        pthread_mutex_unlock(&s_poll_mtx);
        return;
    }

    /* 2. GetPositionInfo */
    buf[0] = 0;
    rc = sonos_soap(g_active_ip, "/MediaRenderer/AVTransport/Control",
                    "urn:schemas-upnp-org:service:AVTransport:1",
                    "GetPositionInfo", "<InstanceID>0</InstanceID>", buf, 32768, 2);
    if (rc == 0) {
        char dur_str[32] = "", rel_str[32] = "", track_uri[256] = "";
        extract_xml_tag(buf, "TrackDuration", dur_str, sizeof dur_str);
        extract_xml_tag(buf, "RelTime", rel_str, sizeof rel_str);
        extract_xml_tag(buf, "TrackURI", track_uri, sizeof track_uri);

        st.duration = parse_time_seconds(dur_str);
        st.elapsed  = parse_time_seconds(rel_str);

        if (strstr(track_uri, "x-sonosapi-stream:") || strstr(track_uri, "x-rincon-mp3radio:") ||
            strstr(track_uri, "hls-radio:") || strstr(track_uri, "aac://") || strstr(track_uri, "http://")) {
            st.is_radio = 1;
        } else {
            st.is_radio = 0;
        }

        /* Extract DIDL metadata */
        char title[96] = "", artist[64] = "", album[64] = "", stream[96] = "", art[256] = "";
        extract_xml_tag(buf, "dc:title", title, sizeof title);
        extract_xml_tag(buf, "dc:creator", artist, sizeof artist);
        if (!artist[0]) extract_xml_tag(buf, "upnp:artist", artist, sizeof artist);
        extract_xml_tag(buf, "upnp:album", album, sizeof album);
        extract_xml_tag(buf, "r:streamContent", stream, sizeof stream);
        extract_xml_tag(buf, "upnp:albumArtURI", art, sizeof art);

        if (st.is_radio && stream[0]) {
            /* Radio stream with currently playing song info */
            if (title[0]) snprintf(st.album, sizeof st.album, "%s", title);
            char * sep = strstr(stream, " - ");
            if (sep) {
                *sep = 0;
                snprintf(st.artist, sizeof st.artist, "%s", stream);
                snprintf(st.title, sizeof st.title, "%s", sep + 3);
            } else {
                snprintf(st.title, sizeof st.title, "%s", stream);
                snprintf(st.artist, sizeof st.artist, "%s", artist[0] ? artist : title);
            }
        } else {
            snprintf(st.title, sizeof st.title, "%s", title);
            snprintf(st.artist, sizeof st.artist, "%s", artist);
            snprintf(st.album, sizeof st.album, "%s", album);
        }
        xml_unescape_in_place(st.title);
        xml_unescape_in_place(st.artist);
        xml_unescape_in_place(st.album);
        sonos_sanitize_utf8(st.title);
        sonos_sanitize_utf8(st.artist);
        sonos_sanitize_utf8(st.album);

        if (art[0]) {
            if (art[0] == '/') {
                snprintf(st.art_url, sizeof st.art_url, "http://%s:1400%s", g_active_ip, art);
            } else {
                snprintf(st.art_url, sizeof st.art_url, "%s", art);
            }
            clean_url(st.art_url);
        }
    }

    /* 3. GetVolume */
    buf[0] = 0;
    rc = sonos_soap(g_active_ip, "/MediaRenderer/RenderingControl/Control",
                    "urn:schemas-upnp-org:service:RenderingControl:1",
                    "GetVolume", "<InstanceID>0</InstanceID><Channel>Master</Channel>", buf, 4096, 2);
    if (rc == 0) {
        char vol_str[16] = "";
        extract_xml_tag(buf, "CurrentVolume", vol_str, sizeof vol_str);
        if (vol_str[0]) st.volume = atoi(vol_str);
    }

    free(buf);

    pthread_mutex_lock(&g_sonos_mtx);
    sonos_state = st;
    pthread_mutex_unlock(&g_sonos_mtx);

    check_trigger_art_download(st.art_url);
    pthread_mutex_unlock(&s_poll_mtx);
}

void sonos_request_refresh(void) {
    g_force_poll = 1;
}

static volatile int g_worker_running = 0;

static void * sonos_worker(void * arg) {
    (void)arg;
    while (g_worker_running) {
        poll_state();
        /* When dimmed, poll every ~8s to preserve network/WiFi power-save.
         * When awake, poll every 2s for responsive playback feedback. */
        int max_slices = ui_is_dimmed() ? 80 : 20;
        for (int i = 0; i < max_slices && g_worker_running; i++) {
            if (g_force_poll) {
                g_force_poll = 0;
                break;
            }
            usleep(100000); /* 100 ms slices */
        }
    }
    return NULL;
}

int sonos_start(void) {
    if (g_sonos_tid) return 0;
    g_worker_running = 1;
    if (pthread_create(&g_sonos_tid, NULL, sonos_worker, NULL) != 0) {
        g_sonos_tid = 0;
        g_worker_running = 0;
        return -1;
    }
    return 0;
}

void sonos_stop(void) {
    if (!g_sonos_tid) return;
    g_worker_running = 0;
    g_force_poll = 1;
    pthread_join(g_sonos_tid, NULL);
    g_sonos_tid = 0;
}

/* =========================================================================
 * Async Control Commands
 * ========================================================================= */

typedef struct {
    char service[64];
    char control_path[64];
    char action[32];
    char body[2048];
} soap_cmd_t;

static void * soap_cmd_worker(void * arg) {
    soap_cmd_t * c = (soap_cmd_t *)arg;
    if (g_active_ip[0]) {
        int rc = sonos_soap(g_active_ip, c->control_path, c->service, c->action, c->body, NULL, 0, 2);
        fprintf(stderr, "[sonos] cmd '%s' -> rc=%d\n", c->action, rc);
    }
    free(c);
    poll_state();
    return NULL;
}

static void send_upnp_cmd(const char * ctrl, const char * svc, const char * act, const char * body) {
    if (!g_active_ip[0]) {
        fprintf(stderr, "[sonos] send_upnp_cmd '%s' dropped: no active IP\n", act ? act : "");
        return;
    }
    soap_cmd_t * c = malloc(sizeof *c);
    if (!c) return;
    snprintf(c->control_path, sizeof c->control_path, "%s", ctrl);
    snprintf(c->service, sizeof c->service, "%s", svc);
    snprintf(c->action, sizeof c->action, "%s", act);
    snprintf(c->body, sizeof c->body, "%s", body ? body : "");

    pthread_t t;
    if (pthread_create(&t, NULL, soap_cmd_worker, c) == 0) {
        pthread_detach(t);
    } else {
        free(c);
    }
}

void sonos_play(void) {
    pthread_mutex_lock(&g_sonos_mtx);
    sonos_state.playing = 1;
    pthread_mutex_unlock(&g_sonos_mtx);
    send_upnp_cmd("/MediaRenderer/AVTransport/Control",
                  "urn:schemas-upnp-org:service:AVTransport:1",
                  "Play", "<InstanceID>0</InstanceID><Speed>1</Speed>");
}

void sonos_pause(void) {
    pthread_mutex_lock(&g_sonos_mtx);
    sonos_state.playing = 0;
    pthread_mutex_unlock(&g_sonos_mtx);
    send_upnp_cmd("/MediaRenderer/AVTransport/Control",
                  "urn:schemas-upnp-org:service:AVTransport:1",
                  "Pause", "<InstanceID>0</InstanceID>");
}

void sonos_play_pause(void) {
    int p;
    pthread_mutex_lock(&g_sonos_mtx);
    p = sonos_state.playing;
    sonos_state.playing = !p;
    pthread_mutex_unlock(&g_sonos_mtx);
    if (p) sonos_pause();
    else sonos_play();
}

void sonos_next(void) {
    send_upnp_cmd("/MediaRenderer/AVTransport/Control",
                  "urn:schemas-upnp-org:service:AVTransport:1",
                  "Next", "<InstanceID>0</InstanceID>");
}

void sonos_prev(void) {
    send_upnp_cmd("/MediaRenderer/AVTransport/Control",
                  "urn:schemas-upnp-org:service:AVTransport:1",
                  "Previous", "<InstanceID>0</InstanceID>");
}

void sonos_seek(int seconds) {
    if (seconds < 0) seconds = 0;
    pthread_mutex_lock(&g_sonos_mtx);
    sonos_state.elapsed = seconds;
    pthread_mutex_unlock(&g_sonos_mtx);

    char target[32];
    snprintf(target, sizeof target, "%02d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, seconds % 60);
    char body[128];
    snprintf(body, sizeof body, "<InstanceID>0</InstanceID><Unit>REL_TIME</Unit><Target>%s</Target>", target);

    send_upnp_cmd("/MediaRenderer/AVTransport/Control",
                  "urn:schemas-upnp-org:service:AVTransport:1",
                  "Seek", body);
}

void sonos_volume_up(void) {
    pthread_mutex_lock(&g_sonos_mtx);
    if (sonos_state.volume <= 98) sonos_state.volume += 2;
    pthread_mutex_unlock(&g_sonos_mtx);
    send_upnp_cmd("/MediaRenderer/RenderingControl/Control",
                  "urn:schemas-upnp-org:service:RenderingControl:1",
                  "SetRelativeVolume",
                  "<InstanceID>0</InstanceID><Channel>Master</Channel><Adjustment>+2</Adjustment>");
}

void sonos_volume_down(void) {
    pthread_mutex_lock(&g_sonos_mtx);
    if (sonos_state.volume >= 2) sonos_state.volume -= 2;
    pthread_mutex_unlock(&g_sonos_mtx);
    send_upnp_cmd("/MediaRenderer/RenderingControl/Control",
                  "urn:schemas-upnp-org:service:RenderingControl:1",
                  "SetRelativeVolume",
                  "<InstanceID>0</InstanceID><Channel>Master</Channel><Adjustment>-2</Adjustment>");
}

void sonos_set_volume(int vol) {
    if (vol < 0) vol = 0;
    if (vol > 100) vol = 100;
    pthread_mutex_lock(&g_sonos_mtx);
    sonos_state.volume = vol;
    pthread_mutex_unlock(&g_sonos_mtx);

    char body[96];
    snprintf(body, sizeof body,
             "<InstanceID>0</InstanceID><Channel>Master</Channel><DesiredVolume>%d</DesiredVolume>", vol);
    send_upnp_cmd("/MediaRenderer/RenderingControl/Control",
                  "urn:schemas-upnp-org:service:RenderingControl:1",
                  "SetVolume", body);
}

void sonos_set_zone(const char * zone) {
    if (!zone || !zone[0]) return;
    snprintf(settings.sonos_zone, sizeof settings.sonos_zone, "%s", zone);

    /* Switch active IP matching this room */
    for (int i = 0; i < g_room_count; i++) {
        if (strcasecmp(g_rooms[i].room, zone) == 0) {
            snprintf(g_active_ip, sizeof g_active_ip, "%s", g_rooms[i].ip);
            snprintf(settings.sonos_host, sizeof settings.sonos_host, "%s", g_rooms[i].ip);
            break;
        }
    }
    settings.sonos_enabled = 1;
    settings_save();

    /* Persist for companion daemon */
    mkdir("/mnt/data/integrations/sonos", 0755);
    if (g_active_ip[0]) {
        FILE * fip = fopen("/mnt/data/integrations/sonos/speaker.ip", "w");
        if (fip) {
            fprintf(fip, "%s\n", g_active_ip);
            fclose(fip);
        }
    }
    FILE * fz = fopen("/mnt/data/integrations/sonos/zone", "w");
    if (fz) {
        fprintf(fz, "%s\n", zone);
        fclose(fz);
    }

    g_force_poll = 1;
}

/* =========================================================================
 * Sonos Favorites & Playlists (ContentDirectory)
 * ========================================================================= */

int sonos_get_favorites(char favs[][64], int max_favs) {
    if (!g_active_ip[0] && g_bootstrap_ip[0]) {
        update_topology(g_bootstrap_ip);
    }
    if (!g_active_ip[0] || max_favs <= 0) return 0;

    char * buf = malloc(65536);
    if (!buf) return 0;
    buf[0] = 0;

    char args[256];
    snprintf(args, sizeof args,
        "<ObjectID>FV:2</ObjectID><BrowseFlag>BrowseDirectChildren</BrowseFlag>"
        "<Filter>*</Filter><StartingIndex>0</StartingIndex><RequestedCount>%d</RequestedCount><SortCriteria></SortCriteria>",
        max_favs);

    int rc = sonos_soap(g_active_ip, "/MediaServer/ContentDirectory/Control",
                        "urn:schemas-upnp-org:service:ContentDirectory:1",
                        "Browse", args, buf, 65536, 3);
    if (rc != 0 || buf[0] == 0) {
        free(buf);
        return 0;
    }

    g_fav_count = 0;
    const char * cur = buf;
    while (cur) {
        const char * p1 = strstr(cur, "<item");
        const char * p2 = strstr(cur, "&lt;item");
        if (!p1 && !p2) break;
        cur = (p1 && p2) ? (p1 < p2 ? p1 : p2) : (p1 ? p1 : p2);
        if (g_fav_count >= max_favs || g_fav_count >= SONOS_MAX_ITEMS) break;

        const char * end_item = strstr(cur, "</item>");
        if (!end_item) end_item = strstr(cur, "&lt;/item&gt;");
        if (!end_item) break;

        char title[64] = "";
        char uri[256] = "";
        char resMD[512] = "";

        extract_xml_tag(cur, "dc:title", title, sizeof title);
        extract_xml_tag(cur, "res", uri, sizeof uri);
        extract_xml_tag(cur, "r:resMD", resMD, sizeof resMD);

        if (title[0] && uri[0]) {
            snprintf(g_favs[g_fav_count].title, sizeof g_favs[0].title, "%s", title);
            snprintf(g_favs[g_fav_count].uri, sizeof g_favs[0].uri, "%s", uri);
            snprintf(g_favs[g_fav_count].meta, sizeof g_favs[0].meta, "%s", resMD);
            snprintf(favs[g_fav_count], 64, "%s", title);
            g_fav_count++;
        }
        cur = end_item + 7;
    }

    free(buf);
    return g_fav_count;
}

static int get_sonos_playlists(sonos_item_t items[], int max_items) {
    if (!g_active_ip[0] && g_bootstrap_ip[0]) {
        update_topology(g_bootstrap_ip);
    }
    if (!g_active_ip[0] || max_items <= 0) return 0;

    char * buf = malloc(65536);
    if (!buf) return 0;
    buf[0] = 0;

    char args[256];
    snprintf(args, sizeof args,
        "<ObjectID>SQ:</ObjectID><BrowseFlag>BrowseDirectChildren</BrowseFlag>"
        "<Filter>*</Filter><StartingIndex>0</StartingIndex><RequestedCount>%d</RequestedCount><SortCriteria></SortCriteria>",
        max_items);

    int rc = sonos_soap(g_active_ip, "/MediaServer/ContentDirectory/Control",
                        "urn:schemas-upnp-org:service:ContentDirectory:1",
                        "Browse", args, buf, 65536, 3);
    if (rc != 0 || buf[0] == 0) {
        free(buf);
        return 0;
    }

    int count = 0;
    const char * cur = buf;
    while (cur) {
        const char * p1 = strstr(cur, "<container");
        const char * p2 = strstr(cur, "&lt;container");
        const char * p3 = strstr(cur, "<item");
        const char * p4 = strstr(cur, "&lt;item");
        const char * p = NULL;
        if (p1 && (!p || p1 < p)) p = p1;
        if (p2 && (!p || p2 < p)) p = p2;
        if (p3 && (!p || p3 < p)) p = p3;
        if (p4 && (!p || p4 < p)) p = p4;
        if (!p) break;
        cur = p;
        if (count >= max_items) break;

        const char * e1 = strstr(cur, "</container>");
        const char * e2 = strstr(cur, "&lt;/container&gt;");
        const char * e3 = strstr(cur, "</item>");
        const char * e4 = strstr(cur, "&lt;/item&gt;");
        const char * end_item = NULL;
        if (e1 && (!end_item || e1 < end_item)) end_item = e1;
        if (e2 && (!end_item || e2 < end_item)) end_item = e2;
        if (e3 && (!end_item || e3 < end_item)) end_item = e3;
        if (e4 && (!end_item || e4 < end_item)) end_item = e4;
        if (!end_item) break;

        char title[64] = "", uri[128] = "", id[64] = "";
        extract_xml_attr(cur, "id", id, sizeof id);
        extract_xml_tag(cur, "dc:title", title, sizeof title);
        extract_xml_tag(cur, "res", uri, sizeof uri);

        if (title[0]) {
            snprintf(items[count].name, sizeof items[0].name, "%s", title);
            snprintf(items[count].uri, sizeof items[0].uri, "%s", uri);
            snprintf(items[count].id, sizeof items[0].id, "%s", id[0] ? id : uri);
            count++;
        }
        cur = end_item + 7;
    }
    free(buf);
    return count;
}

static pthread_mutex_t s_enqueue_mtx = PTHREAD_MUTEX_INITIALIZER;
static volatile int     s_enqueue_seq = 0;

typedef struct {
    char name[64];
    char uri[384];
    char meta[768];
} fav_play_req_t;

static void * fav_play_worker(void * arg) {
    fav_play_req_t * req = (fav_play_req_t *)arg;
    if (!req) return NULL;

    pthread_mutex_lock(&s_enqueue_mtx);
    if (!g_active_ip[0]) {
        pthread_mutex_unlock(&s_enqueue_mtx);
        free(req);
        return NULL;
    }

    char active_ip[32];
    snprintf(active_ip, sizeof active_ip, "%s", g_active_ip);

    char esc_uri[384], esc_meta[768];
    xml_escape(req->uri, esc_uri, sizeof esc_uri);
    xml_escape(req->meta, esc_meta, sizeof esc_meta);

    char body[1280];
    snprintf(body, sizeof body,
             "<InstanceID>0</InstanceID><CurrentURI>%s</CurrentURI><CurrentURIMetaData>%s</CurrentURIMetaData>",
             esc_uri, esc_meta);

    fprintf(stderr, "[sonos] play_favorite starting for '%s'\n", req->name);

    int rc_set = sonos_soap(active_ip, "/MediaRenderer/AVTransport/Control",
                            "urn:schemas-upnp-org:service:AVTransport:1",
                            "SetAVTransportURI", body, NULL, 0, 3);

    int play_ok = 0;
    for (int retry = 0; retry < 5; retry++) {
        int rc = sonos_soap(active_ip, "/MediaRenderer/AVTransport/Control",
                            "urn:schemas-upnp-org:service:AVTransport:1",
                            "Play", "<InstanceID>0</InstanceID><Speed>1</Speed>", NULL, 0, 2);
        if (rc == 0) {
            play_ok = 1;
            break;
        }
        usleep(50000);
    }

    fprintf(stderr, "[sonos] play_favorite result: set=%d play=%d\n", rc_set, play_ok);

    if (play_ok) {
        pthread_mutex_lock(&g_sonos_mtx);
        sonos_state.playing = 1;
        pthread_mutex_unlock(&g_sonos_mtx);
        poll_state();
    }

    pthread_mutex_unlock(&s_enqueue_mtx);
    free(req);
    return NULL;
}

void sonos_play_favorite(const char * name) {
    if (!name || !name[0] || !g_active_ip[0]) return;

    /* Search in cached favorites */
    const sonos_fav_entry_t * match = NULL;
    for (int i = 0; i < g_fav_count; i++) {
        if (strcmp(g_favs[i].title, name) == 0) {
            match = &g_favs[i];
            break;
        }
    }

    if (!match) return;

    fav_play_req_t * req = malloc(sizeof *req);
    if (!req) return;
    snprintf(req->name, sizeof req->name, "%s", name);
    snprintf(req->uri,  sizeof req->uri,  "%s", match->uri);
    snprintf(req->meta, sizeof req->meta, "%s", match->meta);

    pthread_t t;
    if (pthread_create(&t, NULL, fav_play_worker, req) == 0) {
        pthread_detach(t);
    } else {
        free(req);
    }
}

static int get_active_rincon_uuid(char * out_uuid, size_t out_sz) {
    if (!out_uuid || out_sz == 0) return 0;
    out_uuid[0] = 0;

    /* 1. Check cached g_rooms */
    for (int i = 0; i < g_room_count; i++) {
        if ((g_active_ip[0] && strcmp(g_rooms[i].ip, g_active_ip) == 0) ||
            (settings.sonos_zone[0] && strcasecmp(g_rooms[i].room, settings.sonos_zone) == 0)) {
            if (g_rooms[i].uuid[0]) {
                snprintf(out_uuid, out_sz, "%s", g_rooms[i].uuid);
                return 1;
            }
        }
    }

    /* 2. Fallback: query device_description.xml from active IP */
    if (g_active_ip[0]) {
        int fd = socket(AF_INET, SOCK_STREAM, 0);
        if (fd >= 0) {
            struct timeval tv = { .tv_sec = 2, .tv_usec = 0 };
            setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
            setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
            struct sockaddr_in sin;
            memset(&sin, 0, sizeof(sin));
            sin.sin_family = AF_INET;
            sin.sin_port = htons(1400);
            sin.sin_addr.s_addr = inet_addr(g_active_ip);
            if (connect(fd, (struct sockaddr *)&sin, sizeof(sin)) == 0) {
                char req[256];
                int hlen = snprintf(req, sizeof req,
                    "GET /xml/device_description.xml HTTP/1.1\r\n"
                    "Host: %s:1400\r\n"
                    "Connection: close\r\n\r\n", g_active_ip);
                send(fd, req, hlen, 0);
                char desc[4096];
                int r = recv(fd, desc, sizeof(desc) - 1, 0);
                if (r > 0) {
                    desc[r] = 0;
                    char * p = strstr(desc, "<UDN>uuid:");
                    if (p) {
                        p += 10;
                        char * q = strchr(p, '<');
                        if (q) {
                            size_t len = q - p;
                            if (len >= out_sz) len = out_sz - 1;
                            memcpy(out_uuid, p, len);
                            out_uuid[len] = 0;
                            char * col = strchr(out_uuid, ':');
                            if (col) *col = 0;
                        }
                    }
                }
            }
            close(fd);
        }
    }
    fprintf(stderr, "[sonos] resolved uuid='%s' for ip='%s'\n", out_uuid, g_active_ip);
    return out_uuid[0] ? 1 : 0;
}

static void url_encode(const char * src, char * dst, size_t dst_sz) {
    if (!src || !dst || dst_sz == 0) return;
    char * d = dst;
    char * end = dst + dst_sz - 1;
    while (*src && d < end) {
        if (isalnum((unsigned char)*src) || *src == '-' || *src == '_' || *src == '.' || *src == '~') {
            *d++ = *src;
        } else {
            if (d + 3 > end) break;
            sprintf(d, "%%%02x", (unsigned char)*src);
            d += 3;
        }
        src++;
    }
    *d = 0;
}

typedef struct {
    char uri[512];
    char meta[1536];
    char name[64];
    int  first_track;
    int  seq;
} enqueue_play_req_t;

static void * enqueue_play_worker(void * arg) {
    enqueue_play_req_t * req = (enqueue_play_req_t *)arg;
    if (!req) return NULL;

    pthread_mutex_lock(&s_enqueue_mtx);

    /* If a newer request was queued while waiting for lock, discard this one */
    if (req->seq != s_enqueue_seq || !g_active_ip[0]) {
        pthread_mutex_unlock(&s_enqueue_mtx);
        free(req);
        return NULL;
    }

    char active_ip[32];
    snprintf(active_ip, sizeof active_ip, "%s", g_active_ip);

    char uuid[48] = "";
    get_active_rincon_uuid(uuid, sizeof uuid);

    /* If URI was not resolved in caller, resolve it asynchronously here without blocking UI */
    if (req->uri[0] == 0 && req->name[0] != 0) {
        sonos_item_t items[SONOS_MAX_ITEMS];
        int n = get_sonos_playlists(items, SONOS_MAX_ITEMS);
        for (int i = 0; i < n; i++) {
            if (strcmp(items[i].name, req->name) == 0 && items[i].uri[0]) {
                snprintf(req->uri, sizeof req->uri, "%s", items[i].uri);
                break;
            }
        }
        if (!req->uri[0]) {
            snprintf(req->uri, sizeof req->uri, "file:///jffs/settings/savedqueues.rsq#%s", req->name);
        }
    }

    if (!req->uri[0]) {
        pthread_mutex_unlock(&s_enqueue_mtx);
        free(req);
        return NULL;
    }

    fprintf(stderr, "[sonos] enqueue_play starting for uri='%s' (uuid=%s, ip=%s)\n",
            req->uri, uuid, active_ip);

    /* 1. Stop current playback first so speaker releases the transport lock */
    int rc_stop = sonos_soap(active_ip, "/MediaRenderer/AVTransport/Control",
                             "urn:schemas-upnp-org:service:AVTransport:1",
                             "Stop", "<InstanceID>0</InstanceID>", NULL, 0, 3);

    /* 2. Reset transport URI so Sonos unloads previous queue and resets track pointer to 1 */
    int rc_clr = sonos_soap(active_ip, "/MediaRenderer/AVTransport/Control",
                            "urn:schemas-upnp-org:service:AVTransport:1",
                            "SetAVTransportURI",
                            "<InstanceID>0</InstanceID><CurrentURI></CurrentURI><CurrentURIMetaData></CurrentURIMetaData>",
                            NULL, 0, 3);

    /* 3. Clear speaker queue */
    int rc_rem = sonos_soap(active_ip, "/MediaRenderer/AVTransport/Control",
                            "urn:schemas-upnp-org:service:AVTransport:1",
                            "RemoveAllTracksFromQueue", "<InstanceID>0</InstanceID>", NULL, 0, 3);

    /* 4. Add new URI to queue */
    char esc_uri[1024];
    xml_escape(req->uri, esc_uri, sizeof esc_uri);

    char add_body[2048];
    snprintf(add_body, sizeof add_body,
             "<InstanceID>0</InstanceID>"
             "<EnqueuedURI>%s</EnqueuedURI>"
             "<EnqueuedURIMetaData>%s</EnqueuedURIMetaData>"
             "<DesiredFirstTrackNumberEnqueued>0</DesiredFirstTrackNumberEnqueued>"
             "<EnqueueAsNext>0</EnqueueAsNext>",
             esc_uri, req->meta[0] ? req->meta : "");

    int rc_add = sonos_soap(active_ip, "/MediaRenderer/AVTransport/Control",
                            "urn:schemas-upnp-org:service:AVTransport:1",
                            "AddURIToQueue", add_body, NULL, 0, 4);

    /* 5. Switch playback transport to speaker's queue */
    int rc_set = -1;
    if (uuid[0]) {
        char queue_uri[128];
        snprintf(queue_uri, sizeof queue_uri, "x-rincon-queue:%s#0", uuid);
        char set_body[256];
        snprintf(set_body, sizeof set_body,
                 "<InstanceID>0</InstanceID>"
                 "<CurrentURI>%s</CurrentURI>"
                 "<CurrentURIMetaData></CurrentURIMetaData>",
                 queue_uri);
        rc_set = sonos_soap(active_ip, "/MediaRenderer/AVTransport/Control",
                            "urn:schemas-upnp-org:service:AVTransport:1",
                            "SetAVTransportURI", set_body, NULL, 0, 3);
    }

    /* 6. Seek to first_track if specified */
    if (req->first_track > 1) {
        char seek_body[128];
        snprintf(seek_body, sizeof seek_body,
                 "<InstanceID>0</InstanceID><Unit>TRACK_NR</Unit><Target>%d</Target>",
                 req->first_track);
        sonos_soap(active_ip, "/MediaRenderer/AVTransport/Control",
                   "urn:schemas-upnp-org:service:AVTransport:1",
                   "Seek", seek_body, NULL, 0, 3);
    }

    /* 7. Start playback with retry in case speaker is still transitioning */
    int play_ok = 0;
    for (int retry = 0; retry < 5; retry++) {
        int rc = sonos_soap(active_ip, "/MediaRenderer/AVTransport/Control",
                            "urn:schemas-upnp-org:service:AVTransport:1",
                            "Play", "<InstanceID>0</InstanceID><Speed>1</Speed>", NULL, 0, 2);
        if (rc == 0) {
            play_ok = 1;
            break;
        }
        usleep(50000); /* 50 ms */
    }

    fprintf(stderr, "[sonos] enqueue_play result: stop=%d clr=%d rem=%d add=%d set=%d play=%d\n",
            rc_stop, rc_clr, rc_rem, rc_add, rc_set, play_ok);

    if (play_ok) {
        pthread_mutex_lock(&g_sonos_mtx);
        sonos_state.playing = 1;
        pthread_mutex_unlock(&g_sonos_mtx);
        poll_state();
    }

    pthread_mutex_unlock(&s_enqueue_mtx);
    free(req);
    return NULL;
}

static void sonos_enqueue_and_play(const char * uri, const char * meta, const char * name) {
    if (!g_active_ip[0]) return;
    if ((!uri || !uri[0]) && (!name || !name[0])) return;

    enqueue_play_req_t * req = calloc(1, sizeof *req);
    if (!req) return;
    snprintf(req->uri, sizeof req->uri, "%s", uri ? uri : "");
    snprintf(req->meta, sizeof req->meta, "%s", meta ? meta : "");
    snprintf(req->name, sizeof req->name, "%s", name ? name : "");
    req->first_track = 1;
    req->seq = ++s_enqueue_seq;

    pthread_t t;
    if (pthread_create(&t, NULL, enqueue_play_worker, req) == 0) {
        pthread_detach(t);
    } else {
        free(req);
    }
}

void sonos_play_playlist(const char * name) {
    if (!name || !name[0] || !g_active_ip[0]) return;
    if (strncmp(name, "file://", 7) == 0) {
        sonos_enqueue_and_play(name, "", "");
    } else {
        sonos_enqueue_and_play("", "", name);
    }
}

void sonos_play_playlist_track(const char * name, int track_nr) {
    if (!name || !name[0] || !g_active_ip[0]) return;
    enqueue_play_req_t * req = calloc(1, sizeof *req);
    if (!req) return;
    if (strncmp(name, "file://", 7) == 0) {
        snprintf(req->uri, sizeof req->uri, "%s", name);
    } else {
        snprintf(req->name, sizeof req->name, "%s", name);
    }
    req->first_track = track_nr > 0 ? track_nr : 1;
    req->seq = ++s_enqueue_seq;

    pthread_t t;
    if (pthread_create(&t, NULL, enqueue_play_worker, req) == 0) {
        pthread_detach(t);
    } else {
        free(req);
    }
}

void sonos_play_spotify(const char * uri) {
    if (!uri || !uri[0] || !g_active_ip[0]) return;

    if (strncmp(uri, "spotify:", 8) == 0) {
        char enc_uri[256];
        url_encode(uri, enc_uri, sizeof enc_uri);

        char cp_uri[384];
        if (strncmp(uri, "spotify:album:", 14) == 0) {
            snprintf(cp_uri, sizeof cp_uri, "x-rincon-cpcontainer:0004206c%s", enc_uri);
        } else if (strncmp(uri, "spotify:track:", 14) == 0) {
            snprintf(cp_uri, sizeof cp_uri, "x-sonos-spotify:%s?sid=9&amp;flags=8224&amp;sn=1", enc_uri);
        } else {
            snprintf(cp_uri, sizeof cp_uri, "x-rincon-cpcontainer:0006206c%s", enc_uri);
        }

        char didl[1024];
        snprintf(didl, sizeof didl,
            "&lt;DIDL-Lite xmlns:dc=\"http://purl.org/dc/elements/1.1/\" "
            "xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\" "
            "xmlns:r=\"urn:schemas-rinconnetworks-com:metadata-1-0/\" "
            "xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\"&gt;"
            "&lt;item id=\"00030020%s\" restricted=\"true\"&gt;"
            "&lt;upnp:class&gt;object.item.audioItem.musicTrack&lt;/upnp:class&gt;"
            "&lt;desc id=\"cdudn\" nameSpace=\"urn:schemas-rinconnetworks-com:metadata-1-0/\"&gt;"
            "SA_RINCON2311_X_#Svc2311-0-Token&lt;/desc&gt;"
            "&lt;/item&gt;&lt;/DIDL-Lite&gt;",
            enc_uri);

        sonos_enqueue_and_play(cp_uri, didl, "");
    } else {
        sonos_enqueue_and_play(uri, "", "");
    }
}

void sonos_play_spotify_playlist_track(const char * playlist_uri, int track_nr, const char * track_uri) {
    if (!playlist_uri || !playlist_uri[0] || !g_active_ip[0]) return;
    (void)track_uri;

    char enc_uri[256];
    url_encode(playlist_uri, enc_uri, sizeof enc_uri);

    char cp_uri[384];
    snprintf(cp_uri, sizeof cp_uri, "x-rincon-cpcontainer:0006206c%s", enc_uri);

    char didl[1024];
    snprintf(didl, sizeof didl,
        "&lt;DIDL-Lite xmlns:dc=\"http://purl.org/dc/elements/1.1/\" "
        "xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\" "
        "xmlns:r=\"urn:schemas-rinconnetworks-com:metadata-1-0/\" "
        "xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\"&gt;"
        "&lt;item id=\"00030020%s\" restricted=\"true\"&gt;"
        "&lt;upnp:class&gt;object.item.audioItem.musicTrack&lt;/upnp:class&gt;"
        "&lt;desc id=\"cdudn\" nameSpace=\"urn:schemas-rinconnetworks-com:metadata-1-0/\"&gt;"
        "SA_RINCON2311_X_#Svc2311-0-Token&lt;/desc&gt;"
        "&lt;/item&gt;&lt;/DIDL-Lite&gt;",
        enc_uri);

    enqueue_play_req_t * req = calloc(1, sizeof *req);
    if (!req) return;
    snprintf(req->uri, sizeof req->uri, "%s", cp_uri);
    snprintf(req->meta, sizeof req->meta, "%s", didl);
    req->first_track = track_nr > 0 ? track_nr : 1;
    req->seq = ++s_enqueue_seq;

    pthread_t t;
    if (pthread_create(&t, NULL, enqueue_play_worker, req) == 0) {
        pthread_detach(t);
    } else {
        free(req);
    }
}

/* =========================================================================
 * Spotify Web API Integration (Optional user playlist listing)
 * ========================================================================= */

static int extract_json_str(const char * src, const char * key, char * out, size_t outsz) {
    if (!src || !key || !out || outsz == 0) return 0;
    char needle[64];
    snprintf(needle, sizeof needle, "\"%s\"", key);
    const char * p = strstr(src, needle);
    if (!p) return 0;
    p = strchr(p, ':');
    if (!p) return 0;
    p++;
    while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++;
    if (*p != '"') return 0;
    p++;
    size_t n = 0;
    while (*p && *p != '"' && n + 1 < outsz) {
        if (*p == '\\') {
            if (p[1] == 'u' && isxdigit((unsigned char)p[2]) && isxdigit((unsigned char)p[3]) &&
                isxdigit((unsigned char)p[4]) && isxdigit((unsigned char)p[5])) {
                char h[5] = { p[2], p[3], p[4], p[5], 0 };
                unsigned int code = (unsigned int)strtoul(h, NULL, 16);
                p += 6;
                if (code == 0x2018 || code == 0x2019 || code == 0x201A || code == 0x201B || code == 0x2032) {
                    out[n++] = '\'';
                } else if (code == 0x201C || code == 0x201D || code == 0x201E || code == 0x201F || code == 0x2033) {
                    out[n++] = '"';
                } else if (code == 0x2013 || code == 0x2014 || code == 0x2015 || code == 0x2022) {
                    out[n++] = '-';
                } else if (code == 0x2026) {
                    out[n++] = '.';
                } else if (code == 0x00A0) {
                    out[n++] = ' ';
                } else if (code < 0x80) {
                    out[n++] = (char)code;
                } else if (code <= 0x7FF && n + 2 < outsz) {
                    out[n++] = (char)(0xC0 | ((code >> 6) & 0x1F));
                    out[n++] = (char)(0x80 | (code & 0x3F));
                } else if (n + 3 < outsz) {
                    out[n++] = (char)(0xE0 | ((code >> 12) & 0x0F));
                    out[n++] = (char)(0x80 | ((code >> 6) & 0x3F));
                    out[n++] = (char)(0x80 | (code & 0x3F));
                }
                continue;
            } else if (p[1] == 'n' || p[1] == 'r') {
                out[n++] = ' ';
                p += 2;
                continue;
            } else if (p[1]) {
                p++;
            }
        }
        out[n++] = *p++;
    }
    out[n] = 0;
    sonos_sanitize_utf8(out);
    return 1;
}

static int extract_json_int(const char * src, const char * key, int * out) {
    if (!src || !key || !out) return 0;
    char needle[64];
    snprintf(needle, sizeof needle, "\"%s\"", key);
    const char * p = strstr(src, needle);
    if (!p) return 0;
    p = strchr(p, ':');
    if (!p) return 0;
    p++;
    while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++;
    if (*p == '"') p++;
    *out = atoi(p);
    return 1;
}

void sonos_get_spotify_config(sonos_spotify_cfg_t * cfg) {
    if (!cfg) return;
    memset(cfg, 0, sizeof *cfg);
    FILE * f = fopen("/mnt/data/tsc/sonos.userSettings.json", "r");
    if (!f) return;
    char buf[4096];
    size_t n = fread(buf, 1, sizeof(buf) - 1, f);
    fclose(f);
    if (n == 0) return;
    buf[n] = 0;

    extract_json_str(buf, "spotifyClientId", cfg->client_id, sizeof cfg->client_id);
    extract_json_str(buf, "spotifyClientSecret", cfg->client_secret, sizeof cfg->client_secret);
    extract_json_int(buf, "selectedPlaylistUser", &cfg->selected_user);

    if (cfg->client_id[0] && cfg->client_secret[0]) {
        cfg->configured = 1;
    }

    const char * un = strstr(buf, "\"spotifyUserNames\"");
    if (un) {
        const char * p = strchr(un, '[');
        if (p) {
            p++;
            while (*p && *p != ']' && cfg->user_count < 8) {
                while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n' || *p == ',') p++;
                if (*p == '"') {
                    p++;
                    const char * q = strchr(p, '"');
                    if (!q) break;
                    size_t len = (size_t)(q - p);
                    if (len >= sizeof cfg->user_names[0]) len = sizeof cfg->user_names[0] - 1;
                    memcpy(cfg->user_names[cfg->user_count], p, len);
                    cfg->user_names[cfg->user_count][len] = 0;
                    cfg->user_count++;
                    p = q + 1;
                } else {
                    p++;
                }
            }
        }
    }

    const char * ui = strstr(buf, "\"spotifyUserIDs\"");
    if (ui) {
        const char * p = strchr(ui, '[');
        if (p) {
            p++;
            int idx = 0;
            while (*p && *p != ']' && idx < 8) {
                while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n' || *p == ',') p++;
                if (*p == '"') {
                    p++;
                    const char * q = strchr(p, '"');
                    if (!q) break;
                    size_t len = (size_t)(q - p);
                    if (len >= sizeof cfg->user_ids[0]) len = sizeof cfg->user_ids[0] - 1;
                    memcpy(cfg->user_ids[idx], p, len);
                    cfg->user_ids[idx][len] = 0;
                    idx++;
                    p = q + 1;
                } else {
                    p++;
                }
            }
        }
    }
}

static char   s_spot_token[300] = {0};
static time_t s_spot_token_expiry = 0;

static int get_spotify_token(const sonos_spotify_cfg_t * cfg, char * out, size_t outsz) {
    time_t now = time(NULL);
    if (s_spot_token[0] && now < s_spot_token_expiry - 60) {
        snprintf(out, outsz, "%s", s_spot_token);
        return 0;
    }
    if (!cfg || !cfg->configured) return -1;

    char cmd[512];
    snprintf(cmd, sizeof cmd,
        "/usr/bin/curl -s -4 -k --max-time 6 --connect-timeout 4 "
        "-X POST 'https://accounts.spotify.com/api/token' "
        "-d 'grant_type=client_credentials' -u '%s:%s'",
        cfg->client_id, cfg->client_secret);

    FILE * fp = popen(cmd, "r");
    if (!fp) return -1;
    char resp[1024];
    size_t got = fread(resp, 1, sizeof(resp) - 1, fp);
    pclose(fp);
    resp[got] = 0;

    char tok[300] = "";
    if (extract_json_str(resp, "access_token", tok, sizeof tok) && tok[0]) {
        int exp = 3600;
        extract_json_int(resp, "expires_in", &exp);
        snprintf(s_spot_token, sizeof s_spot_token, "%s", tok);
        s_spot_token_expiry = now + exp;
        snprintf(out, outsz, "%s", tok);
        return 0;
    }
    return -1;
}

static int parse_spotify_playlists(const char * json, sonos_item_t items[], int max_items) {
    if (!json || !items || max_items <= 0) return 0;
    int count = 0;
    const char * cur = json;
    while ((cur = strstr(cur, "\"uri\":\"spotify:playlist:")) != NULL && count < max_items) {
        cur += 7;
        const char * q = strchr(cur, '"');
        if (!q) break;
        size_t ulen = (size_t)(q - cur);
        char uri[128];
        if (ulen >= sizeof uri) ulen = sizeof uri - 1;
        memcpy(uri, cur, ulen);
        uri[ulen] = 0;

        const char * search_start = (cur - 1500 > json) ? cur - 1500 : json;
        const char * nm = cur;
        while (nm > search_start) {
            if (strncmp(nm, "\"name\":\"", 8) == 0) break;
            nm--;
        }
        char name[64] = "";
        if (strncmp(nm, "\"name\":\"", 8) == 0) {
            nm += 8;
            const char * nq = strchr(nm, '"');
            if (nq && nq < cur) {
                size_t nlen = (size_t)(nq - nm);
                if (nlen >= sizeof name) nlen = sizeof name - 1;
                memcpy(name, nm, nlen);
                name[nlen] = 0;
            }
        }
        if (name[0] && uri[0]) {
            sonos_sanitize_utf8(name);
            snprintf(items[count].name, sizeof items[count].name, "%s", name);
            snprintf(items[count].uri, sizeof items[count].uri, "%s", uri);
            items[count].id[0] = 0;
            count++;
        }
        cur = q + 1;
    }
    return count;
}

int sonos_get_source_items(sonos_source_t src, int spotify_user_idx, sonos_item_t items[], int max_items) {
    if (!items || max_items <= 0) return 0;
    memset(items, 0, sizeof(sonos_item_t) * max_items);
    if (src == SONOS_SRC_FAVORITES) {
        char favs[SONOS_MAX_ITEMS][64];
        int n = sonos_get_favorites(favs, max_items);
        for (int i = 0; i < n; i++) {
            snprintf(items[i].name, sizeof items[i].name, "%s", favs[i]);
            items[i].uri[0] = 0;
        }
        return n;
    } else if (src == SONOS_SRC_PLAYLISTS) {
        return get_sonos_playlists(items, max_items);
    } else if (src == SONOS_SRC_SPOTIFY) {
        sonos_spotify_cfg_t cfg;
        sonos_get_spotify_config(&cfg);
        if (!cfg.configured || spotify_user_idx < 0 || spotify_user_idx >= cfg.user_count)
            return 0;
        char token[300] = "";
        if (get_spotify_token(&cfg, token, sizeof token) != 0 || !token[0])
            return 0;

        char cmd[512];
        snprintf(cmd, sizeof cmd,
            "/usr/bin/curl -s -4 -k --max-time 6 --connect-timeout 4 "
            "-H 'Authorization: Bearer %s' "
            "'https://api.spotify.com/v1/users/%s/playlists'",
            token, cfg.user_ids[spotify_user_idx]);

        FILE * fp = popen(cmd, "r");
        if (!fp) return 0;
        char * resp = malloc(32768);
        if (!resp) { pclose(fp); return 0; }
        size_t got = fread(resp, 1, 32767, fp);
        pclose(fp);
        resp[got] = 0;
        int count = parse_spotify_playlists(resp, items, max_items);
        free(resp);
        return count;
    }
    return 0;
}

/* =========================================================================
 * Playlist Tracks & Search Implementation
 * ========================================================================= */

static int get_sonos_playlist_tracks(const char * obj_id, sonos_track_t tracks[], int max_tracks) {
    if (!g_active_ip[0] && g_bootstrap_ip[0]) update_topology(g_bootstrap_ip);
    if (!g_active_ip[0] || !obj_id || !obj_id[0] || max_tracks <= 0) return 0;

    char * buf = malloc(131072);
    if (!buf) return 0;
    buf[0] = 0;

    char esc_id[128];
    xml_escape(obj_id, esc_id, sizeof esc_id);

    char args[384];
    snprintf(args, sizeof args,
        "<ObjectID>%s</ObjectID><BrowseFlag>BrowseDirectChildren</BrowseFlag>"
        "<Filter>*</Filter><StartingIndex>0</StartingIndex><RequestedCount>%d</RequestedCount><SortCriteria></SortCriteria>",
        esc_id, max_tracks);

    int rc = sonos_soap(g_active_ip, "/MediaServer/ContentDirectory/Control",
                        "urn:schemas-upnp-org:service:ContentDirectory:1",
                        "Browse", args, buf, 131072, 4);
    if (rc != 0 || buf[0] == 0) {
        free(buf);
        return 0;
    }

    int count = 0;
    const char * cur = buf;
    while (cur && count < max_tracks) {
        const char * p1 = strstr(cur, "<item");
        const char * p2 = strstr(cur, "&lt;item");
        const char * p = NULL;
        if (p1 && (!p || p1 < p)) p = p1;
        if (p2 && (!p || p2 < p)) p = p2;
        if (!p) break;
        cur = p;

        const char * e1 = strstr(cur, "</item>");
        const char * e2 = strstr(cur, "&lt;/item&gt;");
        const char * end_item = NULL;
        if (e1 && (!end_item || e1 < end_item)) end_item = e1;
        if (e2 && (!end_item || e2 < end_item)) end_item = e2;
        if (!end_item) break;

        char title[96] = "", artist[64] = "", album[64] = "", uri[256] = "", dur[32] = "";
        extract_xml_tag(cur, "dc:title", title, sizeof title);
        extract_xml_tag(cur, "dc:creator", artist, sizeof artist);
        if (!artist[0]) extract_xml_tag(cur, "upnp:artist", artist, sizeof artist);
        extract_xml_tag(cur, "upnp:album", album, sizeof album);
        extract_xml_tag(cur, "res", uri, sizeof uri);
        extract_xml_attr(cur, "duration", dur, sizeof dur);

        if (title[0]) {
            snprintf(tracks[count].title, sizeof tracks[0].title, "%s", title);
            snprintf(tracks[count].artist, sizeof tracks[0].artist, "%s", artist);
            snprintf(tracks[count].album, sizeof tracks[0].album, "%s", album);
            snprintf(tracks[count].uri, sizeof tracks[0].uri, "%s", uri);
            tracks[count].track_nr = count + 1;
            if (dur[0]) {
                int h = 0, m = 0, s = 0;
                if (sscanf(dur, "%d:%d:%d", &h, &m, &s) == 3) {
                    tracks[count].duration = h * 3600 + m * 60 + s;
                } else if (sscanf(dur, "%d:%d", &m, &s) == 2) {
                    tracks[count].duration = m * 60 + s;
                }
            }
            count++;
        }
        cur = end_item + 7;
    }
    free(buf);
    return count;
}

static int parse_spotify_track_item(const char * item_str, const char * item_end, sonos_track_t * trk) {
    if (!item_str || !trk) return 0;

    /* 1. Track URI: must be a real playable spotify:track: within this item */
    const char * p_uri = strstr(item_str, "spotify:track:");
    if (!p_uri || (item_end && p_uri >= item_end)) return 0;

    const char * u_end = p_uri;
    while (*u_end && *u_end != '"' && *u_end != ' ' && *u_end != '\n' && *u_end != '\r' &&
           (size_t)(u_end - p_uri) < sizeof(trk->uri) - 1) {
        u_end++;
    }
    size_t u_len = u_end - p_uri;
    memcpy(trk->uri, p_uri, u_len);
    trk->uri[u_len] = '\0';

    /* 2. Artist name: look inside "artists": [ { "name": "..." } ] */
    const char * p_art = strstr(item_str, "\"artists\":");
    if (p_art && (!item_end || p_art < item_end)) {
        extract_json_str(p_art, "name", trk->artist, sizeof(trk->artist));
    } else {
        trk->artist[0] = '\0';
    }

    /* 3. Album name: look inside "album": { "name": "..." } */
    const char * p_alb = strstr(item_str, "\"album\":");
    if (p_alb && (!item_end || p_alb < item_end)) {
        extract_json_str(p_alb, "name", trk->album, sizeof(trk->album));
    } else {
        trk->album[0] = '\0';
    }

    /* 4. Duration */
    int dur_ms = 0;
    const char * p_dur = strstr(item_str, "\"duration_ms\":");
    if (p_dur && (!item_end || p_dur < item_end)) {
        extract_json_int(p_dur, "duration_ms", &dur_ms);
    }
    trk->duration = dur_ms / 1000;

    /* 5. Track title: The track's own "name" key is at the root of the track object,
     * AFTER the "artists": [ ... ] block (which avoids matching album artist or album title). */
    const char * search_name = item_str;
    if (p_art) {
        const char * art_close = strchr(p_art, ']');
        if (art_close && (!item_end || art_close < item_end)) {
            search_name = art_close;
        }
    }
    if (!extract_json_str(search_name, "name", trk->title, sizeof(trk->title)) || !trk->title[0]) {
        extract_json_str(item_str, "name", trk->title, sizeof(trk->title));
    }

    return (trk->title[0] && trk->uri[0]) ? 1 : 0;
}

static int get_spotify_playlist_tracks(const char * uri, sonos_track_t tracks[], int max_tracks) {
    if (!uri || !uri[0] || max_tracks <= 0) return 0;
    sonos_spotify_cfg_t cfg;
    sonos_get_spotify_config(&cfg);
    if (!cfg.configured) return 0;

    char token[300] = "";
    if (get_spotify_token(&cfg, token, sizeof token) != 0 || !token[0]) return 0;

    const char * id = uri;
    if (strncmp(id, "spotify:playlist:", 17) == 0) id += 17;
    else if (strstr(id, ":playlist:")) id = strstr(id, ":playlist:") + 10;

    int req_limit = max_tracks > 100 ? 100 : max_tracks;
    if (req_limit < 50) req_limit = 50;

    char cmd[700];
    snprintf(cmd, sizeof cmd,
        "/usr/bin/curl -s -4 -k --max-time 10 --connect-timeout 4 "
        "-H 'Authorization: Bearer %s' "
        "'https://api.spotify.com/v1/playlists/%s/tracks?limit=%d&fields=items(track(name,uri,duration_ms,artists(name),album(name)))'",
        token, id, req_limit);

    FILE * fp = popen(cmd, "r");
    if (!fp) return 0;
    size_t bufsz = 131072; /* 128 KB */
    char * resp = malloc(bufsz);
    if (!resp) { pclose(fp); return 0; }
    size_t got = fread(resp, 1, bufsz - 1, fp);
    pclose(fp);
    resp[got] = 0;

    int count = 0;
    const char * cur = resp;
    while ((cur = strstr(cur, "\"track\":")) != NULL && count < max_tracks) {
        cur += 8;
        while (*cur == ' ' || *cur == '\t' || *cur == '\n' || *cur == '\r') cur++;
        if (strncmp(cur, "null", 4) == 0) {
            cur += 4;
            continue;
        }

        const char * next_item = strstr(cur, "\"track\":");

        sonos_track_t trk;
        memset(&trk, 0, sizeof trk);
        if (parse_spotify_track_item(cur, next_item, &trk)) {
            trk.track_nr = count + 1;
            tracks[count++] = trk;
        }
    }
    free(resp);
    return count;
}

int sonos_get_playlist_tracks(sonos_source_t src, const char * id_or_uri, sonos_track_t tracks[], int max_tracks) {
    if (!id_or_uri || !tracks || max_tracks <= 0) return 0;
    if (src == SONOS_SRC_PLAYLISTS) {
        return get_sonos_playlist_tracks(id_or_uri, tracks, max_tracks);
    } else if (src == SONOS_SRC_SPOTIFY) {
        return get_spotify_playlist_tracks(id_or_uri, tracks, max_tracks);
    }
    return 0;
}

int sonos_spotify_search(const char * query, sonos_search_result_t * result) {
    if (!query || !query[0] || !result) return 0;
    memset(result, 0, sizeof *result);

    sonos_spotify_cfg_t cfg;
    sonos_get_spotify_config(&cfg);
    if (!cfg.configured) return 0;

    char token[300] = "";
    if (get_spotify_token(&cfg, token, sizeof token) != 0 || !token[0]) return 0;

    char esc_q[128];
    url_encode(query, esc_q, sizeof esc_q);

    char cmd[512];
    snprintf(cmd, sizeof cmd,
        "/usr/bin/curl -s -4 -k --max-time 8 --connect-timeout 4 "
        "-H 'Authorization: Bearer %s' "
        "'https://api.spotify.com/v1/search?q=%s&type=track,album,playlist&limit=20'",
        token, esc_q);

    FILE * fp = popen(cmd, "r");
    if (!fp) return 0;
    char * resp = malloc(65536);
    if (!resp) { pclose(fp); return 0; }
    size_t got = fread(resp, 1, 65535, fp);
    pclose(fp);
    resp[got] = 0;

    const char * tr_sec = strstr(resp, "\"tracks\":");
    const char * alb_sec = strstr(resp, "\"albums\":");
    const char * pl_sec = strstr(resp, "\"playlists\":");

    /* 1. Parse tracks */
    if (tr_sec) {
        const char * cur = tr_sec;
        while ((cur = strstr(cur, "\"name\":")) != NULL && result->track_count < 25) {
            if (alb_sec && cur >= alb_sec) break;
            if (pl_sec && cur >= pl_sec) break;

            char name[96] = "", uri[128] = "", artist[64] = "";
            int dur_ms = 0;
            extract_json_str(cur, "name", name, sizeof name);
            extract_json_str(cur, "uri", uri, sizeof uri);
            extract_json_int(cur, "duration_ms", &dur_ms);

            const char * art = strstr(cur, "\"artists\":");
            if (art && (!alb_sec || art < alb_sec)) {
                extract_json_str(art, "name", artist, sizeof artist);
            }

            if (name[0] && strncmp(uri, "spotify:track:", 14) == 0) {
                snprintf(result->tracks[result->track_count].name, sizeof result->tracks[0].name, "%s", name);
                snprintf(result->tracks[result->track_count].artist, sizeof result->tracks[0].artist, "%s", artist);
                snprintf(result->tracks[result->track_count].uri, sizeof result->tracks[0].uri, "%s", uri);
                result->tracks[result->track_count].duration = dur_ms / 1000;
                result->track_count++;
            }
            cur += 7;
        }
    }

    /* 2. Parse albums */
    if (alb_sec) {
        const char * cur = alb_sec;
        while ((cur = strstr(cur, "\"name\":")) != NULL && result->album_count < 25) {
            if (pl_sec && cur >= pl_sec) break;

            char name[96] = "", uri[128] = "", artist[64] = "";
            extract_json_str(cur, "name", name, sizeof name);
            extract_json_str(cur, "uri", uri, sizeof uri);

            const char * art = strstr(cur, "\"artists\":");
            if (art && (!pl_sec || art < pl_sec)) {
                extract_json_str(art, "name", artist, sizeof artist);
            }

            if (name[0] && strncmp(uri, "spotify:album:", 14) == 0) {
                snprintf(result->albums[result->album_count].name, sizeof result->albums[0].name, "%s", name);
                snprintf(result->albums[result->album_count].artist, sizeof result->albums[0].artist, "%s", artist);
                snprintf(result->albums[result->album_count].uri, sizeof result->albums[0].uri, "%s", uri);
                result->album_count++;
            }
            cur += 7;
        }
    }

    /* 3. Parse playlists */
    if (pl_sec) {
        const char * cur = pl_sec;
        while ((cur = strstr(cur, "\"name\":")) != NULL && result->playlist_count < 25) {
            char name[96] = "", uri[128] = "", owner[64] = "";
            extract_json_str(cur, "name", name, sizeof name);
            extract_json_str(cur, "uri", uri, sizeof uri);

            const char * ow = strstr(cur, "\"owner\":");
            if (ow) {
                extract_json_str(ow, "display_name", owner, sizeof owner);
            }

            if (name[0] && strstr(uri, ":playlist:")) {
                snprintf(result->playlists[result->playlist_count].name, sizeof result->playlists[0].name, "%s", name);
                snprintf(result->playlists[result->playlist_count].artist, sizeof result->playlists[0].artist, "%s", owner);
                snprintf(result->playlists[result->playlist_count].uri, sizeof result->playlists[0].uri, "%s", uri);
                result->playlist_count++;
            }
            cur += 7;
        }
    }

    free(resp);
    return result->track_count + result->album_count + result->playlist_count;
}
